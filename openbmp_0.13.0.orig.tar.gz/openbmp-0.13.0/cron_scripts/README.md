Cron Scripts have moved to openbmp-mysql-consumer
-------------------------------------------------

The cron scripts are specific to the MySQL database implementation.  These scripts have moved to the new openbmp-mysql-consumer. 

New Location is: [https://github.com/OpenBMP/openbmp-mysql-consumer](https://github.com/OpenBMP/openbmp-mysql-consumer)
