Database has moved to openbmp-mysql-consumer
--------------------------------------------

All the same features and schemas have been moved to the new Kafka MySQL consumer.

New Location is: [https://github.com/OpenBMP/openbmp-mysql-consumer](https://github.com/OpenBMP/openbmp-mysql-consumer)







