Release Notes - Version 0.12.0
==============================
Updated for Kafka 0.9.x, added advanced topic mapping and bug fixes. 


Change Log
----------------

### New Features/Changes

* Kafka 0.9.0 support
* Configuration file support
* Advanced topic mapping
* Full IPv6 listening support

### Defects/Fixes

* Minor bug fixes



